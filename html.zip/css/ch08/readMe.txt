학습목표

position fixed에 대해 알아보자

position fixed 를 이용하면 스크롤을 해도 항상 제자리에 머무른다. 스크롤 내려도 화면에 그대로 있옴.

처음 만들어진 자리에 고정되어 있다. 하지만 top,  left, right, bottom
중 하나만 수정해도 서로 다른 레이어 위치에 놓이게 된다.

맨 앞에 레이어에 위치하게 된다.
position의 기본값은 static임.