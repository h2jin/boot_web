학습 목표

Relative 와 Absolute에 대해 알아보자

position : static
position : fixed
position : relative
- element가 처음 생성된 위치를 기준으로 top, bottom, left, right 로 조금씩 위치를 수정할 수 있다.
position : absolute 
- 가장 가까운 relative 부모 기준으로 이동한다. (없으면 body)