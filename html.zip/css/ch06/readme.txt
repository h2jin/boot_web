학습목표

Border에 대해 알아보자

Border는 block 요소, inline 요소 둘 다 적용이 된다. 
