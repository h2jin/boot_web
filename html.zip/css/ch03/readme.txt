학습 목표

블록 요소와 인라인 요소와
Blocks and inline

div는 옆에 다른 div가 오지 않는다. - 블록 속성
span 태그는 옆에 다른 span태그가 올 수 있다. - 인라인 속성

p는 옆에 올 수 없다. - Block

옆에 다른 요소가 못오는 것 block, 올 수 있는 태그는 inline 요소(in the same line)

inline의 대표적인 태그(span, a, img)
