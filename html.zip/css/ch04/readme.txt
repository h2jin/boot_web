
학습 목표
block 요소의 특징

margine, padding, border 다 가질 수 있음 + 높이와 너비도 가질 수 있다.

**
inline도 margine, padding, border 값 가질 수 있음
단, 높이와 너비는 무시된다.

기본 스타일값들이 지정되어 있다.
(ex, body에 block 처리, margine 8px)