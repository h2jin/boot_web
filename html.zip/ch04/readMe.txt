div 태그에 대해서 알아보자

div는 division 이라는 단어에서 나왔다. (분할, 구분, 경계선)

div (박스모델)
: 의미가 없는 태그, 의마가 있는 태크로 대체하고있다. ()
(semantic, non-semantic)